import java.util.ArrayList;


public class Permutation
{
	public static ArrayList<ArrayList<Integer>> permutation(final ArrayList<Integer> list)
	{
		// TO DO
		ArrayList<ArrayList<Integer>> result = new ArrayList<ArrayList<Integer>>();
		permute(list, 0, result);
		return result;
	}
	
	public static void permute(ArrayList<Integer> list, int start, ArrayList<ArrayList<Integer>> result)
	{
		if (start >= list.size()) 
		{
			ArrayList<Integer> current = fillCurrentList(list);
			result.add(current);
		}
 
		for (int j = start; j <= list.size() - 1; j++) 
		{
			swap(list, start, j);
			permute(list, start + 1, result);
			swap(list, start, j);
		}
	}
	
	private static ArrayList<Integer> fillCurrentList(ArrayList<Integer> list)
	{
		ArrayList<Integer> current = new ArrayList<Integer>();
		
		for(int i = 0; i < list.size(); i++)
			current.add(list.get(i));
		
		return current;
	}
 
	private static void swap(ArrayList<Integer> list, int i, int j) 
	{
		int temp = list.get(i);
		list.set(i, list.get(j));
		list.set(j, temp);

	}
}
