/**
 * It is okay to use ArrayList class but you are not allowed to use any other
 * predefined class supplied by Java.
 */
import java.util.ArrayList;
import java.io.*;

public class CompressDecompress extends CompressDecompressGUI
{
	/**
	 * Get a string representing a Huffman tree where its root node is root
	 * @param root the root node of a Huffman tree
	 * @return a string representing a Huffman tree
	 */
	public static String getTreeString(final BinaryNodeInterface<Character> root)
	{
		// TO DO
		String resultString = "";
        
		if(root == null)
			return "";
		
		//Check to see if the current node is a leafNode.
		if(root.isLeaf())
			resultString += "L" + root.getData();
		else
		{
			resultString += "I";
			resultString += getTreeString(root.getLeftChild());
			resultString += getTreeString(root.getRightChild());
			
		}

		return resultString;	// Do not forget to change this line!!!
	}

	/**
	 * Compress the message using Huffman tree represented by resultString
	 * @param root the root node of a Huffman tree
	 * @param message the message to be compressed
	 * @return a string representing compressed message.
	 */
	public static String compress(final BinaryNodeInterface<Character> root, final String message)
	{
		StringBuilder sb = new StringBuilder();
		ArrayList<Character> characterList = new ArrayList<Character>();
		ArrayList<String> outputCodeList = new ArrayList<String>();
		
		compressHelper(root, "", characterList, outputCodeList);
		
		for(int i = 0; i < message.length(); i++)
		{
			sb.append(outputCodeList.get(characterList.indexOf(message.charAt(i))));
		}
		
		return sb.toString();
	}
	private static void compressHelper(BinaryNodeInterface<Character> currentNode, String path, ArrayList<Character> characterList, ArrayList<String> outputcode)
	{
		if(currentNode != null)
		{
			if(currentNode.isLeaf())
			{
				characterList.add(currentNode.getData());
				outputcode.add(path);
			}
			compressHelper(currentNode.getLeftChild(), path + "0", characterList, outputcode);
			compressHelper(currentNode.getRightChild(), path + "1", characterList, outputcode);
		}
	}
	
	private static String getPathTo(final BinaryNodeInterface<Character> root, char c)
	{
		// TO DO
		StringBuilder sb = new StringBuilder();
		String path = "";
		
		if(root.getData() != null)
		{
			if(root.getData() == c)
			{
				return path;
			}
		}
		if(root.hasLeftChild())
		{
			String s = getPathTo(root.getLeftChild(), c);
			if(s != null)
			{
				path += "0";
				path += s;
				return path;
			}
		}
		
		if(root.hasRightChild())
		{
			String s = getPathTo(root.getRightChild(), c);
			if(s != null)
			{
				path += "1";
				path += s;
				return path;
			}
		}
		
		return null;
	}
	
	/**
	 * Decompress the message using Huffman tree represented by resultString
	 * @param resultString the string represents the Huffman tree of the
	 * compressed message
	 * @param message the compressed message to be decompressed
	 * @return a string representing decompressed message
	 */
	public static String decompress(final String treeString, final String message)
	{
		StringBuilder sb = new StringBuilder();
		
		ArrayList<Character> list = new ArrayList<Character>();
		
		for(int i = 0; i < treeString.length(); i++)
		{
			list.add(treeString.charAt(i));
		}
		
		BinaryNodeInterface<Character> root = build(list);
		BinaryNodeInterface<Character> currentNode = root;
		
		for(int i = 0; i < message.length(); i++)
		{
			if(message.charAt(i) == '0') 
			{
				currentNode =currentNode.getLeftChild();
			}
			else 
			{
				currentNode = currentNode.getRightChild();
			}
			
			if(currentNode.isLeaf())
			{
				sb.append(currentNode.getData());
				currentNode = root;
			}
		}
		
		return sb.toString();
	}

	private static BinaryNode<Character> build(ArrayList<Character> list)
	{
		if(list.isEmpty()) 
			return null;
		
		char x = list.remove(0);
		
		if(x == 'L')
			return new BinaryNode<Character>(list.remove(0), null, null);
		else
			return new BinaryNode<Character>(null, build(list), build(list));
	}
	
}
