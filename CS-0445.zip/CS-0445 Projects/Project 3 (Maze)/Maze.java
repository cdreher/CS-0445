import java.util.Random;
// No other import statement is allowed

public class Maze
{
	// TO DO: Instance Variable
	private int width, height;
	private Random r = new Random();
	private boolean[][] southWall, eastWall;
	
	/**
	 * Constructor
	 * @param aWidth the number of chambers in each row
	 * @param aHeight the number of chamber in each column
	 */
	public Maze(int aWidth, int aHeight)
	{
		// TO DO: Constructor
		width = aWidth;
		height = aHeight;
		southWall = new boolean[aHeight][aWidth];
		eastWall = new boolean[aHeight][aWidth];
		for(int i = 0; i < height; i++)
		{
			for(int j = 0; j < width; j++)
			{
				southWall[i][j] = false;
				eastWall[i][j] = false;
			}
		}
		
		mazeHelper(0, aWidth, 0, aHeight);
	}
	
	private void mazeHelper(int startWidth, int aWidth, int startHeight, int aHeight)
	{
		if(aHeight - startHeight <= 1 || aWidth - startWidth <= 1)
		{
			return;
		}
		else
		{
			//Pick random point.
			int rowIndex = r.nextInt(aHeight-1 - startHeight) + startHeight;
			int columnIndex = r.nextInt(aWidth-1 - startWidth) + startWidth;
			
			//Draw appropriate south wall.
			for(int i = startWidth; i < aWidth; i++)
			{
				southWall[rowIndex][i] = true;
			}
			//Draw appropriate east wall.
			for(int i = startHeight; i < aHeight; i++)
			{
				eastWall[i][columnIndex] = true;
			}
			
			remove(rowIndex, columnIndex, startWidth, aWidth, startHeight, aHeight);
			
			mazeHelper(startWidth, columnIndex + 1, startHeight, rowIndex + 1);
			mazeHelper(columnIndex + 1, aWidth, startHeight, rowIndex + 1);
			mazeHelper(startWidth, columnIndex + 1, rowIndex + 1, aHeight);
			mazeHelper(columnIndex + 1, aWidth, rowIndex + 1, aHeight);
		}
	}

	/**
	 * getWidth
	 * @return the width of this maze
	 */
	public int getWidth()
	{
		// TO DO 
		return width;
	}
	
	/**
	 * getHeight
	 * @return the height of this maze
	 */
	public int getHeight()
	{
		// TO DO
		return height;
	}
	
	/**
	 * isNorthWall
	 * @param row the row identifier of a chamber
	 * @param column the column identifier of a chamber
	 * @return true if the chamber at row row and column column
	 * contain a north wall. Otherwise, return false
	 */
	public boolean isNorthWall(int row, int column)
	{
		// TO DO
		if(row == 0)
			return true;
		return southWall[row - 1][column];
		
	}
	
	/**
	 * isEastWall
	 * @param row the row identifier of a chamber
	 * @param column the column identifier of a chamber
	 * @return true if the chamber at row row and column column
	 * contain an east wall. Otherwise, return false
	 */
	public boolean isEastWall(int row, int column)
	{
		// TO DO
		if(column == height - 1)
			return true;
		return eastWall[row][column];
	}
	
	/**
	 * isSouthWall
	 * @param row the row identifier of a chamber
	 * @param column the column identifier of a chamber
	 * @return true if the chamber at row row and column column
	 * contain a south wall. Otherwise, return false
	 */
	public boolean isSouthWall(int row, int column)
	{
		// TO DO
		if(row == width - 1)
			return true;
		return southWall[row][column];
	}
	
	/**
	 * isWestWall
	 * @param row the row identifier of a chamber
	 * @param column the column identifier of a chamber
	 * @return true if the chamber at row row and column column
	 * contain a west wall. Otherwise, return false
	 */
	public boolean isWestWall(int row, int column)
	{
		// TO DO
		if(column == 0)
			return true;
		return eastWall[row][column - 1];
	}
	
	private void remove(int row, int column, int startWidth, int aWidth, int startHeight, int aHeight)
	{
		//Randomly pick which wall will remain entirely the same.
		int randomWall = r.nextInt(4);
		int wallToRemove = 0;
		
		if(randomWall == 0)
		{
			//Remove SOUTH WALL.
			column++;
			wallToRemove = r.nextInt(aWidth - column) + column;
			southWall[row][wallToRemove] = false;
			column--;
			
			//Remove EAST WALL.
			row++;
			wallToRemove = r.nextInt(aHeight - row) + row;
			eastWall[wallToRemove][column] = false;
			row--;
			
			//Remove SOUTH WALL.
			column++;
			wallToRemove = r.nextInt(column - startWidth) + startWidth;
			southWall[row][wallToRemove] = false;
			column--;
		}
		else if(randomWall == 1)
		{
			//Remove SOUTH WALL.
			row++;
			wallToRemove = r.nextInt(row - startHeight) + startHeight;
			eastWall[wallToRemove][column] = false;
			row--;
			
			//Remove EAST WALL.
			row++;
			wallToRemove = r.nextInt(aHeight - row) + row;
			eastWall[wallToRemove][column] = false;
			row--;
			
			//Remove SOUTH WALL.
			column++;
			wallToRemove = r.nextInt(column - startWidth) + startWidth;
			southWall[row][wallToRemove] = false;
			column--;
		}
		else if(randomWall == 2)
		{
			//Remove SOUTH WALL.
			row++;
			wallToRemove = r.nextInt(row - startHeight) + startHeight;
			eastWall[wallToRemove][column] = false;
			row--;
			
			//Remove SOUTH WALL.
			column++;
			wallToRemove = r.nextInt(aWidth - column) + column;
			southWall[row][wallToRemove] = false;
			column--;
			
			//Remove SOUTH WALL.
			column++;
			wallToRemove = r.nextInt(column - startWidth) + startWidth;
			southWall[row][wallToRemove] = false;
			column--;
		}
		else if(randomWall == 3)
		{
			//Remove SOUTH WALL.
			row++;
			wallToRemove = r.nextInt(row - startHeight) + startHeight;
			eastWall[wallToRemove][column] = false;
			row--;
			
			//Remove SOUTH WALL.
			column++;
			wallToRemove = r.nextInt(aWidth - column) + column;
			southWall[row][wallToRemove] = false;
			column--;
			
			//Remove EAST WALL.
			row++;
			wallToRemove = r.nextInt(aHeight - row) + row;
			eastWall[wallToRemove][column] = false;
			row--;
			
		}
		
		
		
	}
}
