import java.util.*;
import java.io.*;

public class CharacterFrequency
{
	public static void main(String[] args) throws IOException
	{
		FrequencyBag<Character> fb = new FrequencyBag<Character>();
		File f = new File("E:/CS-0445 Projects/Project 1/letter1.txt");
		Scanner keyboard = new Scanner(f);
		BufferedReader reader = new BufferedReader(new FileReader(f));
		
		int x;
		
		while((x = reader.read()) != -1)
		{
			fb.add(Character.toLowerCase((char) x));
			
		}
		
		char[] letters = "abcdefghijklmnopqrstuvwxyz".toCharArray();
		
		System.out.println("Character: Frequency");
		System.out.println("====================");
		
		for(int i = 0; i < 26; i++)
		{
			System.out.println(letters[i] + ": " + fb.getFrequencyOf(new Character(letters[i])));
		}
	}
}