
public class FrequencyBag<T>
{
	// TO DO: Instance Variables
	private Node firstNode;
	private int numEntries;
	/**
	 * Constructor
	 * Constructs an empty frequency bag.
	 */
	public FrequencyBag()
	{
		firstNode = null;
		numEntries = 0;
	}
	
	/**
	 * Adds new entry into this frequency bag.
	 * @param aData the data to be added into this frequency bag.
	 */
	public void add(T aData)
	{
		// TO DO
		Node currentNode = firstNode;
		int count = 1;
		boolean added = false;
		
		while(currentNode != null && !added)
		{
			if(currentNode.data.equals(aData))
			{
				count = currentNode.frequency;
				count++;
				currentNode.frequency = count;
				numEntries++;
				added = true;
			}
			else
			{
				currentNode = currentNode.next;
			}
		}
		
		if(numEntries == 0 || !added)
		{
			Node newNode = new Node(aData, 1);
			newNode.next = firstNode;
			firstNode = newNode;
			numEntries++;
			added = true;
		}
	}
	
	/**
	 * Gets the number of occurrences of aData in this frequency bag.
	 * @param aData the data to be checked for its number of occurrences.
	 * @return the number of occurrences of aData in this frequency bag.
	 */
	public int getFrequencyOf(T aData)
	{
		// TO DO
		Node currentNode = firstNode;
		
		while(currentNode != null)
		{
			if(currentNode.data.equals(aData))
			{
				return currentNode.frequency;
			}
			else
			{
				currentNode = currentNode.next;
			}
		}
		
		return 0;
		
	}

	/**
	 * Gets the maximum number of occurrences in this frequency bag.
	 * @return the maximum number of occurrences of an entry in this
	 * frequency bag.
	 */
	public int getMaxFrequency()
	{
		// TO DO
		Node currentNode = firstNode;
		int maxFrequency = 0;
		
		while(currentNode != null)
		{
			if(currentNode.frequency > maxFrequency)
				maxFrequency = currentNode.frequency;
			
			currentNode = currentNode.next;
		}
		
		return maxFrequency;
	}
	
	/**
	 * Gets the probability of aData
	 * @param aData the specific data to get its probability.
	 * @return the probability of aData
	 */
	public double getProbabilityOf(T aData)
	{
		// TO DO
		return ((double)getFrequencyOf(aData))/(double)size();
	}

	/**
	 * Empty this bag.
	 */
	public void clear()
	{
		// TO DO
		firstNode = null;
		numEntries = 0;
	}
	
	/**
	 * Gets the number of entries in this bag.
	 * @return the number of entries in this bag.
	 */
	public int size()
	{
		// TO DO
		Node currentNode = firstNode;
		int total = 0;
		
		while(currentNode != null)
		{
			total += currentNode.frequency;
			currentNode = currentNode.next;
		}
		
		return total;
	}
	
	public class Node
	{
		private int frequency;
		private T data;
		private Node next;
		
		private Node(T dataPortion, int numOccurrences)
		{
			data = dataPortion;
			frequency = numOccurrences;
			next = null;
		}
		private Node(T dataPortion, int numOccurrences, Node nextNode)
		{
			data = dataPortion;
			frequency = numOccurrences;
			next = nextNode;
		}
	}
}
