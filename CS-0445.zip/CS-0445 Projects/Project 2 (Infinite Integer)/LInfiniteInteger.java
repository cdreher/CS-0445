import java.util.Arrays;
public class LInfiniteInteger implements InfiniteIntegerInterface
{
	private Node firstNode;
	private Node lastNode;
	private Node currentNode;
	private int numberOfDigits;
	private boolean isNegative = false;
	
	/**
	 * Constructor: Constructs this infinite integer from a string
	 * representing an integer.
	 * @param s  a string represents an integer
	 */
	public LInfiniteInteger(String s)
	{
		// TO DO
		if(s.isEmpty())
		{
			numberOfDigits = 0;
			firstNode = null;
			lastNode = null;
			isNegative = false;
		}
		else
		{
			StringBuilder sb = new StringBuilder(s);
			if(s.charAt(0) == '-')
			{
				isNegative = true;
				s = sb.deleteCharAt(0).toString();
				while(s.charAt(0) == '0')
				{
					s = sb.deleteCharAt(0).toString();
					if(s.isEmpty())
					{
						firstNode = new Node(null, 0, null);
						lastNode = firstNode;
						numberOfDigits = 1;
						isNegative = false;
						break;
					}
				}
				
				if(s.length() == 0)
				{
					firstNode = new Node(null, 0, null);
					lastNode = firstNode;
				}
				else
				{
					numberOfDigits = s.length();
					for(int i = 0; i < s.length(); i++)
					{
						if(firstNode == null)
						{
							firstNode = new Node(null, Character.getNumericValue(s.charAt(0)), null);
							lastNode = firstNode;
						}
						else
						{
							Node newNode = new Node(lastNode, Character.getNumericValue(s.charAt(i)), null);
							lastNode.next = newNode;
							lastNode = newNode;
						}
					}
				}
			}
			
			else
			{
				isNegative = false;
				while(s.charAt(0) == '0')
				{
					s = sb.deleteCharAt(0).toString();
					if(s.isEmpty())
					{
						firstNode = new Node(null, 0, null);
						lastNode = firstNode;
						numberOfDigits = 1;
						isNegative = false;
						break;
					}
				}
				
				if(s.length() == 0)
				{
					firstNode = new Node(null, 0, null);
					lastNode = firstNode;
				}
				else
				{
					numberOfDigits = s.length();
					for(int i = 0; i < s.length(); i++)
					{
						if(firstNode == null)
						{
							firstNode = new Node(null, Character.getNumericValue(s.charAt(0)), null);
							lastNode = firstNode;
						}
						else
						{
							Node newNode = new Node(lastNode, Character.getNumericValue(s.charAt(i)), null);
							lastNode.next = newNode;
							lastNode = newNode;
						}
					}
				}
			}
		}		
	}

	/**
	 * Constructor: Constructs this infinite integer from an integer.
	 * @param anInteger  an integer
	 */
	public LInfiniteInteger(int anInteger)
	{
		// TO DO
		StringBuilder anInt = new StringBuilder();
		anInt.append(anInteger);
		String s = anInt.toString();
	
		if(s.isEmpty())
		{
			numberOfDigits = 0;
			firstNode = null;
			lastNode = null;
			isNegative = false;
		}
		
		else
		{
			StringBuilder sb = new StringBuilder(s);
			if(s.charAt(0) == '-')
			{
				isNegative = true;
				s = sb.deleteCharAt(0).toString();
				while(s.charAt(0) == '0')
				{
					s = sb.deleteCharAt(0).toString();
					if(s.isEmpty())
					{
						firstNode = new Node(null, 0, null);
						lastNode = firstNode;
						numberOfDigits = 1;
						isNegative = false;
						break;
					}
				}
				
				numberOfDigits = s.length();
				for(int i = 0; i < s.length(); i++)
				{
					if(firstNode == null)
					{
						firstNode = new Node(null, Character.getNumericValue(s.charAt(0)), null);
						lastNode = firstNode;
					}
					else
					{
						Node newNode = new Node(lastNode, Character.getNumericValue(s.charAt(i)), null);
						lastNode.next = newNode;
						lastNode = newNode;
					}
				
					
				}
			}
			
			else
			{
				isNegative = false;
				while(s.charAt(0) == '0')
				{
					s = sb.deleteCharAt(0).toString();
					if(s.isEmpty())
					{
						firstNode = new Node(null, 0, null);
						lastNode = firstNode;
						numberOfDigits = 1;
						isNegative = false;
						break;
					}
				}
				
				
				if(s.isEmpty() == false)
				{
					numberOfDigits = s.length();
					for(int i = 0; i < s.length(); i++)
					{
						if(firstNode == null)
						{
							firstNode = new Node(null, Character.getNumericValue(s.charAt(0)), null);
							lastNode = firstNode;
						}
						else
						{
							Node newNode = new Node(lastNode, Character.getNumericValue(s.charAt(i)), null);
							lastNode.next = newNode;
							lastNode = newNode;
						}
					}
				}
			}
		}			
		
	}

	/**
	 * Gets the number of digits of this infinite integer.
	 * @return an integer representing the number of digits
	 * of this infinite integer.
	 */
	public int getNumberOfDigits()
	{
		// TO DO
		return numberOfDigits;
	}

	/**
	 * Checks whether this infinite integer is a negative number.
	 * @return true if this infinite integer is a negative number.
	 * Otherwise, return false.
	 */
	public boolean isNegative()
	{
		// TO DO
		return isNegative;
	}

	/**
	 * Calculates the result of this infinite integer plus anInfiniteInteger
	 * @param anInfiniteInteger the infinite integer to be added to this
	 * infinite integer.
	 * @return a NEW infinite integer representing the result of this
	 * infinite integer plus anInfiniteInteger
	 */
	public InfiniteIntegerInterface plus(final InfiniteIntegerInterface anInfiniteInteger)
	{		
		// TO DO
		int firstArrayIndex = numberOfDigits - 1;
		int index = 0;
		int secondArrayIndex = anInfiniteInteger.getNumberOfDigits() - 1;
		int carry = 0;
		int sizeOfTempResult, temp;
		int tempResultIndex = 0;
		int[] finalResultArray, tempResultArray;
		InfiniteIntegerInterface firstInteger;
		boolean resultantIsNegative;
		String secondString = "";
		
		//Find size of temp result array
		if(numberOfDigits > anInfiniteInteger.getNumberOfDigits())
			sizeOfTempResult = numberOfDigits;
		else
			sizeOfTempResult = anInfiniteInteger.getNumberOfDigits();
		
		tempResultArray = new int[sizeOfTempResult];
		tempResultIndex = sizeOfTempResult - 1;
		
		if(anInfiniteInteger.toString().equals("0"))
			return this;
		else if(this.toString().equals("0"))
			return anInfiniteInteger;
		else if(isNegative == anInfiniteInteger.isNegative())
		{	
			//Fill first array
			int[] firstArray = new int[numberOfDigits];
			currentNode = firstNode;
			
			while(currentNode != null)
			{
				firstArray[index] = currentNode.data;
				currentNode = currentNode.next;
				index++;
				
			}
			
			index = 0;
			
			//Fill second array
			int[] secondArray = new int[anInfiniteInteger.getNumberOfDigits()];
			StringBuilder sb = new StringBuilder();
			sb.append(anInfiniteInteger);
			if(sb.charAt(0) == '-')
				secondString = sb.deleteCharAt(0).toString();
			else	
				secondString = sb.toString();
			
			for(int i = 0; i < secondString.length(); i++)
			{
				secondArray[i] = Character.getNumericValue(secondString.charAt(i));
			}
		
			while(firstArrayIndex >= 0 && secondArrayIndex >= 0)
			{
				if(carry != 0)
					temp = firstArray[firstArrayIndex] + secondArray[secondArrayIndex] + carry;
				else
					temp = firstArray[firstArrayIndex] + secondArray[secondArrayIndex];
				
				if(temp >= 10)
				{
					carry = 1;
					tempResultArray[tempResultIndex] = (temp - 10);
				}
				else
				{
					carry = 0;
					tempResultArray[tempResultIndex] = temp;
				}
				
				firstArrayIndex--;
				secondArrayIndex--;
				tempResultIndex--;
			}
			
			while(firstArrayIndex >= 0)
			{
				if(carry == 1)
					temp = firstArray[firstArrayIndex] + carry;
				else
					temp = firstArray[firstArrayIndex];
				
				if(temp == 10)
				{
					carry = 1;
					tempResultArray[tempResultIndex] = (temp - 10);
				}
				else
				{
					carry = 0;
					tempResultArray[tempResultIndex] = temp;
				} 
				
				firstArrayIndex--;
				tempResultIndex--;
			}
			
			while(secondArrayIndex >= 0)
			{
				if(carry == 1)
					temp = secondArray[secondArrayIndex] + carry;
				else
					temp = secondArray[secondArrayIndex];
				
				if(temp == 10)
				{
					
					carry = 1;
					tempResultArray[tempResultIndex] = (temp - 10);
				}
				else
				{
					carry = 0;
					tempResultArray[tempResultIndex] = temp;
				} 
				
				secondArrayIndex--;
				tempResultIndex--;
			}
			
			if(carry == 1)
			{
				finalResultArray = new int[tempResultArray.length + 1];
				
				finalResultArray[0] = carry;
				
				for(int i = 0; i < tempResultArray.length; i++)
				{
					finalResultArray[i + 1] = tempResultArray[i]; 
				}
			}
			else
			{
				finalResultArray = new int[tempResultArray.length];
				
				for(int i = 0; i < tempResultArray.length; i++)
				{
					finalResultArray[i] = tempResultArray[i];
				}
			}
			
			StringBuilder sb2 = new StringBuilder();
			
			for(int i = 0; i < finalResultArray.length; i++)
			{
				sb2.append(finalResultArray[i]);
			}
			
			String finalResult = "";
			
			if(isNegative)
				finalResult = "-" + sb2.toString();
			else 	
				finalResult = sb2.toString();
			
			InfiniteIntegerInterface x = new LInfiniteInteger(finalResult);
			return x;
		}
		
		else
		{	
			if(isNegative)
			{			
				StringBuilder sb = new StringBuilder(this.toString());
				String s = sb.deleteCharAt(0).toString();
				firstInteger = new LInfiniteInteger(s);
					
				//Fill first array
				int[] firstArray = new int[numberOfDigits];
				currentNode = firstNode;
				
				while(currentNode != null)
				{
					firstArray[index] = currentNode.data;
					currentNode = currentNode.next;
					index++;
				}
				
				index=0;
				
				//Fill second array
				int[] secondArray = new int[anInfiniteInteger.getNumberOfDigits()];
				StringBuilder sb2 = new StringBuilder();
				sb2.append(anInfiniteInteger);
				secondString = sb2.toString();
				InfiniteIntegerInterface secondInteger = new LInfiniteInteger(secondString);
				
				for(int i = 0; i < secondString.length(); i++)
				{
					secondArray[i] = Character.getNumericValue(secondString.charAt(i));
				}
				
				
				if(firstInteger.compareTo(secondInteger) == 1)
				{
					resultantIsNegative = true;
					while(firstArrayIndex >= 0 && secondArrayIndex >= 0)
					{
						if(carry == -1)
							temp = firstArray[firstArrayIndex] - secondArray[secondArrayIndex] + carry;
						else
							temp = firstArray[firstArrayIndex] - secondArray[secondArrayIndex];
						
						if(temp < 0)
						{
							temp += 10;
							carry = -1;
							tempResultArray[tempResultIndex] = temp;
						}
						else
						{
							carry = 0;
							tempResultArray[tempResultIndex] = temp;
						}
						
						firstArrayIndex--;
						secondArrayIndex--;
						tempResultIndex--;
					}
				}
				else
				{
					resultantIsNegative = false;
					while(firstArrayIndex >= 0 && secondArrayIndex >= 0)
					{
						if(carry == -1)
							temp = secondArray[secondArrayIndex] - firstArray[firstArrayIndex] + carry;
						else
							temp = secondArray[secondArrayIndex] - firstArray[firstArrayIndex];
						
						if(temp < 0)
						{
							temp += 10;
							carry = -1;
							tempResultArray[tempResultIndex] = temp;
						}
						else
						{
							carry = 0;
							tempResultArray[tempResultIndex] = temp;
						}
						
						firstArrayIndex--;
						secondArrayIndex--;
						tempResultIndex--;
					}
				}
			
				while(firstArrayIndex >= 0)
				{
					if(carry == -1)
						temp = firstArray[firstArrayIndex] + carry;
					else
						temp = firstArray[firstArrayIndex];
					
					if(temp < 0)
					{
						temp += 10;
						carry = -1;
						tempResultArray[tempResultIndex] = temp;
					}
					else
					{
						carry = 0;
						tempResultArray[tempResultIndex] = temp;
					} 
					
					firstArrayIndex--;
					tempResultIndex--;
				}
				
				while(secondArrayIndex >= 0)
				{
					if(carry == -1)
						temp = secondArray[secondArrayIndex] + carry;
					else
						temp = secondArray[secondArrayIndex];
					
					if(temp < 0)
					{
						
						temp += 10;
						carry = -1;
						tempResultArray[tempResultIndex] = temp;
					}
					else
					{
						carry = 0;
						tempResultArray[tempResultIndex] = temp;
					} 
					
					secondArrayIndex--;
					tempResultIndex--;
				}
				
				finalResultArray = new int[tempResultArray.length];
					
				for(int i = 0; i < tempResultArray.length; i++)
				{
					finalResultArray[i] = tempResultArray[i];
				}
				
				
				StringBuilder sb4 = new StringBuilder();
				
				for(int i = 0; i < finalResultArray.length; i++)
				{
					sb4.append(finalResultArray[i]);
				}
				
				String finalResult = "";
				
				if(resultantIsNegative)
					finalResult = "-" + sb4.toString();
				else
					finalResult = sb4.toString();
				
				InfiniteIntegerInterface x = new LInfiniteInteger(finalResult);
				return x;
			}
			else
			{
				firstInteger = new LInfiniteInteger(this.toString());
				
				StringBuilder sb7 = new StringBuilder();
				sb7.append(anInfiniteInteger);
				secondString = sb7.deleteCharAt(0).toString();
				InfiniteIntegerInterface secondInteger = new LInfiniteInteger(secondString);
				
				//Fill first array
				int[] firstArray = new int[numberOfDigits];
				currentNode = firstNode;
				
				while(currentNode != null)
				{
					firstArray[index] = currentNode.data;
					currentNode = currentNode.next;
					index++;
				}
				
				index = 0;
				
				//Fill second array
				int[] secondArray = new int[anInfiniteInteger.getNumberOfDigits()];
				
				for(int i = 0; i < secondString.length(); i++)
				{
					secondArray[i] = Character.getNumericValue(secondString.charAt(i));
				}
				
				
				if(firstInteger.compareTo(secondInteger) == 1)
				{
					resultantIsNegative = false;
					while(firstArrayIndex >= 0 && secondArrayIndex >= 0)
					{
						if(carry == -1)
							temp = firstArray[firstArrayIndex] - secondArray[secondArrayIndex] + carry;
						else
							temp = firstArray[firstArrayIndex] - secondArray[secondArrayIndex];
						
						if(temp < 0)
						{
							temp += 10;
							carry = -1;
							tempResultArray[tempResultIndex] = temp;
						}
						else
						{
							carry = 0;
							tempResultArray[tempResultIndex] = temp;
						}
						
						firstArrayIndex--;
						secondArrayIndex--;
						tempResultIndex--;
					}
				}
				else
				{
					resultantIsNegative = true;
					while(firstArrayIndex >= 0 && secondArrayIndex >= 0)
					{
						if(carry == -1)
							temp = secondArray[secondArrayIndex] - firstArray[firstArrayIndex] + carry;
						else
							temp = secondArray[secondArrayIndex] - firstArray[firstArrayIndex];
						
						if(temp < 0)
						{
							temp += 10;
							carry = -1;
							tempResultArray[tempResultIndex] = temp;
						}
						else
						{
							carry = 0;
							tempResultArray[tempResultIndex] = temp;
						}
						
						firstArrayIndex--;
						secondArrayIndex--;
						tempResultIndex--;
					}
				}
				
			
				while(firstArrayIndex >= 0)
				{
					if(carry == -1)
						temp = firstArray[firstArrayIndex] + carry;
					else
						temp = firstArray[firstArrayIndex];
					
					if(temp < 0)
					{
						temp += 10;
						carry = -1;
						tempResultArray[tempResultIndex] = temp;
					}
					else
					{
						carry = 0;
						tempResultArray[tempResultIndex] = temp;
					} 
					
					firstArrayIndex--;
					tempResultIndex--;
				}
				
				while(secondArrayIndex >= 0)
				{
					if(carry == -1)
						temp = secondArray[secondArrayIndex] + carry;
					else
						temp = secondArray[secondArrayIndex];
					
					if(temp < 0)
					{
						
						temp += 10;
						carry = -1;
						tempResultArray[tempResultIndex] = temp;
					}
					else
					{
						carry = 0;
						tempResultArray[tempResultIndex] = temp;
					} 
					
					secondArrayIndex--;
					tempResultIndex--;
				}
				
				finalResultArray = new int[tempResultArray.length];
					
				for(int i = 0; i < tempResultArray.length; i++)
				{
					finalResultArray[i] = tempResultArray[i];
				}
				
				
				StringBuilder sb2 = new StringBuilder();
				
				for(int i = 0; i < finalResultArray.length; i++)
				{
					sb2.append(finalResultArray[i]);
				}
				
				String finalResult = "";
				
				if(resultantIsNegative)
					finalResult = "-" + sb2.toString();
				else
					finalResult = sb2.toString();
				
				InfiniteIntegerInterface x = new LInfiniteInteger(finalResult);
				return x;
			}
		}
		
	}

	/**
	 * Calculates the result of this infinite integer subtracted by anInfiniteInteger
	 * @param anInfiniteInteger the infinite integer to subtract.
	 * @return a NEW infinite integer representing the result of this
	 * infinite integer subtracted by anInfiniteInteger
	 */
	public InfiniteIntegerInterface minus(final InfiniteIntegerInterface anInfiniteInteger)
	{
		// TO DO
		StringBuilder sb = new StringBuilder();
		String s = sb.append(anInfiniteInteger).toString();
		
		if(this.toString().equals("0"))
			if(s.charAt(0) == ('-'))
			{
				s = sb.deleteCharAt(0).toString();
				InfiniteIntegerInterface newSecondInteger = new LInfiniteInteger(s);
				return newSecondInteger;
			}
			else
			{
				s = sb.insert(0, "-").toString();
				InfiniteIntegerInterface newSecondInteger = new LInfiniteInteger(s);
				return newSecondInteger;
			}
				
		else if(s.equals("0"))
			return this;
		else if(anInfiniteInteger.isNegative())
		{
			s = sb.deleteCharAt(0).toString();
			InfiniteIntegerInterface newSecondInteger = new LInfiniteInteger(s);
			return this.plus(newSecondInteger);
		}
		else
		{
			s = sb.insert(0, "-").toString();
			InfiniteIntegerInterface newSecondInteger = new LInfiniteInteger(s);
			return this.plus(newSecondInteger);
		}
		 
	}
	
	/**
	 * Generates a string representing this infinite integer. If this infinite integer
	 * is a negative number a minus symbol should be in the front of numbers. For example,
	 * "-12345678901234567890". But if the infinite integer is a positive number, no symbol
	 * should be in the front of the numbers (e.g., "12345678901234567890").
	 * @return a string representing this infinite integer number.
	 */
	public String toString()
	{
		// TO DO
		currentNode = firstNode;
		String s = "";
		while(currentNode != null)
		{
			s = s.concat(Integer.toString(currentNode.data));
			currentNode = currentNode.next;
		}
		
		if(isNegative)
			s = "-" + s;
		
		return s;
		
	}
	
	/**
	 * Compares this infinite integer with anInfiniteInteger
	 * @return either -1, 0, or 1 as follows:
	 * If this infinite integer is less than anInfiniteInteger, return -1.
	 * If this infinite integer is equal to anInfiniteInteger, return 0.
	 * If this infinite integer is greater than anInfiniteInteger, return 1.
	 */
	public int compareTo(InfiniteIntegerInterface anInfiniteInteger)
	{
		// TO DO
		int digits = anInfiniteInteger.getNumberOfDigits();
		char[] array1 = anInfiniteInteger.toString().toCharArray();;
		int index = 0;
		int result = 0;
		
		if(isNegative == anInfiniteInteger.isNegative())
		{
			if(digits < numberOfDigits)
				return 1;
			
			else if(digits > numberOfDigits)
				return -1;
			else
			{
				currentNode = firstNode;
				while(currentNode != null)
				{
					if(currentNode.data > Character.getNumericValue(array1[index]))
					{
						return 1;
					}
					else if(currentNode.data < Character.getNumericValue(array1[index]))
					{
						return -1;
					}
				
					currentNode = currentNode.next;
					index++;
					result = 0;
					
				}
			
			}
		
		}
		
		else if(!isNegative && anInfiniteInteger.isNegative())
			return 1;
		else if(isNegative && !anInfiniteInteger.isNegative())	
			return -1;
		return result;
	}

	/**
	 * Calculates the result of this infinite integer multiplied by anInfiniteInteger
	 * @param anInfiniteInteger the multiplier.
	 * @return a NEW infinite integer representing the result of this
	 * infinite integer multiplied by anInfiniteInteger.
	 */
	public InfiniteIntegerInterface multiply(final InfiniteIntegerInterface anInfiniteInteger)
	{
		// TO DO
		InfiniteIntegerInterface[] arr = new InfiniteIntegerInterface[10];
		arr[0] = new LInfiniteInteger(0);
		arr[1] = anInfiniteInteger;
		arr[2] = arr[1].plus(arr[1]);
		arr[3] = arr[2].plus(arr[1]);
		arr[4] = arr[2].plus(arr[2]);
		arr[5] = arr[3].plus(arr[2]);
		arr[6] = arr[3].plus(arr[3]);
		arr[7] = arr[4].plus(arr[3]);
		arr[8] = arr[4].plus(arr[4]);
		arr[9] = arr[4].plus(arr[5]);
		
		int zeros = 0;
		Node newNode = lastNode;
		String temp = "";
		InfiniteIntegerInterface result = new LInfiniteInteger(0);
		
		if(toString().equals("0") || anInfiniteInteger.toString().equals("0"))
		{
			result = new LInfiniteInteger(0);
			return result;
		}
		
		while(newNode != null)
		{
			temp = (arr[newNode.data].toString());
			
			
			for(int i = 0; i < zeros; i++)
			{
				temp = temp.concat("0");
			}
			
			zeros++;
			
			InfiniteIntegerInterface temp2 = new LInfiniteInteger(temp);
			result = result.plus(temp2);
			newNode = newNode.previous;
		}
		
		if(isNegative == anInfiniteInteger.isNegative())
		{
			if(result.isNegative())
			{
				StringBuilder sb = new StringBuilder(result.toString());
				result = new LInfiniteInteger(sb.deleteCharAt(0).toString());
			}
		}
		else
		{
			if(result.isNegative() == false)
			{
				String s = "-" + result.toString();
				result = new LInfiniteInteger(s);
			}
		}
		return result;
		
	}
	
	private class Node
	{
		private int data;
		private Node next;
		private Node previous;
		
		private Node(Node previousNode, int aData, Node nextNode)
		{
			previous = previousNode;
			data = aData;
			next = nextNode;
		}
		
		private Node(int aData)
		{
			this(null, aData, null);
		}
	}
}
